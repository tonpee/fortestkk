package mainpack;

import util.Theerakan.Util045;

public class Main045 {
    public static void main(String[] args) {
        testTheerakan();
        testCompute045RightTriangleArea();
        testEvaluate045();
        testComputeMagicTheerakan();
    }
    //3.1 - 3.4
    public static void testTheerakan() {
        System.out.println("3.1: theerakan: " + Util045.theerakan);
    }

    public static void testCompute045RightTriangleArea() {
        System.out.println("3.2: compute045RightTriangleArea(3.0,4.0): " + Util045.compute045RightTriangleArea(3.0, 4.0));
    }

    public static void testEvaluate045() {
        System.out.println("3.3: evaluate045(75.0): " + Util045.evaluate045(75.0));
    }

    public static void testComputeMagicTheerakan() {
        System.out.println("3.4: computeMagicTheerakan(1,15,6): " + Util045.computeMagicTheerakan(1,15,6));
    }
    //4.2 - 4.6
    
}

