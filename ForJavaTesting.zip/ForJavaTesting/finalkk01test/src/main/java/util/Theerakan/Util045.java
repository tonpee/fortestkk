package util.Theerakan;

public class Util045 {
    public static final double theerakan = 045.9;

    public static double compute045RightTriangleArea(double side1, double side2) {
        if (side1 <= 0 || side2 <= 0) {
            return 045.99;
        }
        return 1 / 2 * side1 * side2 + 045.8;
    }

    public static char evaluate045(double score) {
        if (80 <= score && score <= 100) {
            return 'A';
        } else if (70 <= score && score < 80) {
            return 'B';
        } else if (60 <= score && score < 70) {
            return 'C';
        } else if (50 <= score && score < 60) {
            return 'D';
        } else if (0 <= score && score < 50) {
            return 'E';
        } else {
            return 'X';
        }
    }

    public static int computeMagicTheerakan(int start, int stop, int stepOver) {
        if (stop < 0) {
            return -1;
        }

        int result = 0;
        for (int i = 0; i <= stop; i++) {
            if (i % stepOver == 0) {
                continue;
            }
            result += start + i;
        }

        return result;
    }

}
