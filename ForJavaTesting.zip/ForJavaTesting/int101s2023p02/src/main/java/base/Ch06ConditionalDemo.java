package base;

import java.util.Random;

public class Ch06ConditionalDemo {

   public static void main(String[] args) {
      System.out.println("### Demo Conditional Statements and Expressions ###");
      demoIfStatement();
      demoIfElseStatement();
      demoNestedIfStatement();
      demoSwitchColonStatement();
      demoSwitchArrowStatement();
      demoSwitchExpression();
      demoTernaryConditionalExpression();        
   }

   static void demoIfStatement() {
      System.out.println("## Demo if (boolean) { trueBlock; } ##");
      // if (BOOLEAN_EXPRESSION) oneStatement;
      // if (BOOLEAN_EXPRESSION) { BLOCK }
      
      // BOOLEAN EXPRESSION ==> 
      //   boolean operations: &&, || (short-circuit); &, |, !
      //   relational operations: <, >, <=, >= (numeric types); ==, != (all types)
      //   method invocations returning boolean values: e.g., .equals()

      // Math.random() returns a "double" value v where 0.0 <= v < 1.0.
      double d = 10.0 * Math.random(); // 0.0 <= d < 10.0
      System.out.println("# d = " + d);

      // -----------------------
      if (d < 10.0) // only one statement in if-statement
         System.out.println("if-statement: d less than 10.0"); 

      // -----------------------
      // use {}-block if there are more than one statements in if-statement
      if (d >= 0.0) { 
         System.out.print("If-statement with multiple actions: ");
         System.out.println("d is 0.0 or more.");
      }

      // -----------------------
      if (d < 7.0) System.out.println("If-statement: d is lower than 7.0");

      // -----------------------
      if (d > 3.0 && d < 8.0) 
         System.out.println("If-statement: d is in between 3.0 and 8.0.");
   }

   static void demoIfElseStatement() {
      System.out.println("## Demo if (boolean) { trueBlock; } else { falseBlock; } ##");
      // if (BOOLEAN_EXPRESSION) 
      //    STATEMENT_OR_BLOCK_FOR_TRUE;
      // else
      //    STATEMENT_OR_BLOCK_FOR_FALSE;

      int i = 5 + (int) (3 * Math.random()); // 5 <= i < 5+3 ... i=5,6,7

      Random r = new Random();
      // r.nextInt(v) returns an "int" value j where 0 <= j < v
      int j = 5 + r.nextInt(3); // 5 <= j < 5+3 ... j=5,6,7

      System.out.println("# i=" + i + ",j=" + j + " #");

      // -----------------------
      if (i == j)
         System.out.println("If-Else-statement: i is equal to j"); 
      else 
         System.out.println("If-Else-statement: i is not equal to j.");

      // -----------------------
      // {}-block can be used in both if-statement and else-statement.
      if (i / j > 0) { 
         System.out.println("If-Else-statement: i >= j");
      } else {
         System.out.println("If-Else-statement: i < j");
      }
   }

   static void demoNestedIfStatement() {
      System.out.println("## Demo if (...) { ... } else if (...) { ... } else { ... } ##");
      // if (BOOLEAN_EXPRESSION_1)
      //    if (BOOLEAN_EXPRESION_2)
      //       STATEMENT_OR_BLOCK_FOR_EXPRESSION_1_TRUE_AND_EXPRESSION_2_TRUE
      //    else
      //       STATEMENT_OR_BLOCK_FOR_EXPRESSION_1_TRUE_AND_EXPRESSION_2_FALSE
      // else
      //    STATEMENT_OR_BLOCK_FOR_EXPRESSION_1_FALSE
      
      // if (BOOLEAN_EXPRESSION_1)
      //    STATEMENT_OR_BLOCK_FOR_EXPRESSION_1_TRUE
      // else if (BOOLEAN_EXPRESION_2)
      //    STATEMENT_OR_BLOCK_FOR_EXPRESSION_1_FALSE_AND_EXPRESSION_2_TRUE
      // else
      //    STATEMENT_OR_BLOCK_FOR_EXPRESSION_1_FALSE_AND_EXPRESSION_2_FALSE

      double d = Math.random();
      System.out.print("# d is a uniform distribution where 0.0 <= d < 1.0.");
      System.out.println(" (d = " + d + ") #");

      // -----------------------
      if (d < 0.25) {
         System.out.println("d is between 0.0 and 0.25.");
      } else if (d < 0.5) {
         System.out.println("d is between 0.25 and 0.5.");
      } else if (d < 0.75) {
         System.out.println("d is between 0.5 and 0.75.");
      } else {
         System.out.println("d is between 0.75 and 1.0.");
      }

      // -----------------------
      Random r = new Random();
      // r.nextGaussian() returns a "double" value of
      // normal distribution with standard deviation = 1.0 and mean = 0.0. 
      d =  r.nextGaussian();
      System.out.print("# d is normal distribution with mean=0.0, sd=1.0.");
      System.out.println(" (d = " + d + ") #");

      // -----------------------
      if (d > -2.0 && d < 2.0)
         if (d > 0.0)
            System.out.println("Nested If: d is positive, within 2 SDs from mean.");
         else // this "else" belongs to the above nearest "if"
            System.out.println("Nested If: d is negative, within 2 SDs from mean.");         
      else // this "else" belongs to the top-level "if" 
           // because the nearest "if" has already had "else"
         System.out.println("Nested if: d is beyond 2-SD boundary from mean.");
      
   }
   static void demoSwitchColonStatement() {
      System.out.println("## Demo Switch with Colon Case ##");
      // switch-case statement: COLON CASE
      // switch (EXPRESSION) {
      //    case CONSTANT_EXPRESSION :
      //       ZERO_OR_MORE_STATEMENTS;
      //       break; // execution will continue until "break" or end of "switch" 
      //    default : // "default" is optional and need not be the last one
      //       ZERO_OR_MORE_STATEMENTS; // the last case needs no break
      // }

      char c = (char) ('a' + 12 * Math.random()); // x = 'a' ... 'h'
      System.out.println("# c is '" + c + "' #");
      
      // -----------------------
      // expression in switch () must returns 
      // byte, short, char, int, String, or enum only.
      // long, float, double, or any object is not allowed.
      switch (c) {
         // each case must be unique
         case 'a' :
            System.out.println("This is 'Ant'.");
            break; // each case needs a "break" 
            // to jump out of the switch-case statement
         case 'b' :
            break; // this case does nothing.
         case 'd' :
            System.out.println("This is not 'Ant' and not 'Bee'.");
            // when case does not have a "break", 
            // it will not jump out of the switch-case statement
            // but it will continue to execute the next case
         case 'e' :
            // cases do not need to be sorted 
         case 'f', 'c' :
            // case 'c', 'e', and 'f' are combined using , and : 
            System.out.print("This is 'Cat', Dog'");
            System.out.println(", 'Elephant', or 'Fish'.");
            break;
         default : // default case can be anywhere and default is optional
            System.out.println("What is 'Kiwi' or 'Lion'? " + c);
            break;            
         case 'j', 'h', 'g', 'i' :
            System.out.print("This is 'Gorilla', 'Horse'");
            System.out.println(", 'Iguana' or 'Jellyfish'.");
            // the last case does not need a "break"
      }
   }
   
   static void demoSwitchArrowStatement() {
      System.out.println("## Demo Switch with Arrow Case ##");
      // switch-case statement: ARROW CASE
      //    same as COLON CASE except that "break" is not used.
      // switch (EXPRESSION) {
      //    case CONSTANT_EXPRESSION ->
      //       ONE_STATEMENT_OR_ONE_BLOCK;
      // }

      char c = (char) ('a' + 12 * Math.random()); // x = 'a' ... 'h'
      System.out.println("# c is '" + c + "' #");

      // -----------------------
      // expression in switch () must returns 
      // byte, short, char, int, String, or enum only.
      // long, float, double, or any object is not allowed.
      switch (c) {
         // each case must be unique
         // arrow case do not use "break" but it breaks explicitly.
         case 'a' -> System.out.println("This is 'Ant'.");
         case 'b' -> { } // this case does nothing.
         case 'e', 'f', 'c' -> { 
            // if an arrow case contains multiple statements, 
            // {}-block is required.
            System.out.print("This is 'Cat' or 'Elephant'");
            System.out.println(" or 'Fish'.");
         }
         case 'd' -> System.out.println("This is 'Dog'.");
         default -> // default case can be anywhere and it is optional
            System.out.println("Is it 'Kiwi' or 'Lion'? " + c);           
         case 'j', 'h', 'g', 'i' -> {
            System.out.print("This is 'Gorilla', 'Horse'");
            System.out.println(", 'Iguana' or 'Jellyfish'.");
         }
      }
   }
   
   static void demoSwitchExpression() {
      System.out.println("## Demo Switch Case Expression ##");
      // switch-case statement: ARROW CASE
      //    same as COLON CASE except that "break" is not used.
      // switch (EXPRESSION) {
      //    case CONSTANT_EXPRESSION ->
      //       ONE_STATEMENT_OR_ONE_BLOCK;
      // }

      String s = "" + (char) ('A' + 2 * Math.random())
                + (char) ('X' + 3 * Math.random());
      System.out.println("# s is [" + s + "] #");

      // -----------------------
      String r = 
         // switch case expression
         switch (s) {
            case "BY" -> "bye bye"; // return "bye bye"

            // default is required for switch-case expression 
            // because an expression must return something.
            default -> "meaningless"; // it can be anywhere.

            case "AX", "AZ" -> {
               System.out.println("...(AX or AZ)...");
               yield "an axe"; 
               // if it is an arrow case that contains a block,
               // use "yield" to return a value.
            }
         };
      System.out.println("Result = " + r);

      // -----------------------
      String t = "" + (char) ('D' + 2 * Math.random())
                + (char) ('O' + 2 * Math.random());
      System.out.println("# t is [" + t + "] #");
      System.out.println("Result = " +
         switch (t) {
            // colon case uses "yield" to return a value 
            // and "break" is not used in switch-case expression.
            case "DO" : 
               yield "do did done"; // return "do did done"
            case "EO", "EP" : 
               System.out.println("(... E ...)");
               yield "contains 'E'";

            // default is required for switch-case expression 
            // because an expression must return something.
            default : 
               yield "meaningless"; // it can be anywhere.
         });
   }

   static void demoTernaryConditionalExpression() {
      System.out.println("## Demo Ternary Conditional Expression ##");
      // Ternary Conditional Expression:
      //   BOOLEAN_EXPRESSION ? EXPRESSION_FOR_TRUE : EXPRESSION_FOR_FALSE;
      // ==> right associativity
      // ==> short-circuit expression  
      //
      // Right Associativity:
      //  (A ? B : C ? D : E) is_the_same_as (A ? B : (C ? D : E))
      //  (A ? B : C ? D : E) is_not         ((A ? B : C) ? D : E)
      //  (A ? B : C ? D : E) is_equivalent_to
      //  if (A) 
      //     return B
      //  else if (C)
      //     return D
      //  else 
      //     return E
      //
      // Short-Circuit Expression:
      //  if BOOLEAN_EXPRESSION is evaluated to true, 
      //     EXPRESSION_FOR_TRUE will be evaluated and returned
      //     but EXPRESSION_FOR_FALSE will not be evaluated.
      //  if BOOLEAN_EXPRESSION is evaluated to false, 
      //     EXPRESSION_FOR_FALSE will be evaluated and returned
      //     but EXPRESSION_FOR_TRUE will not be evaluated.

      Random r = new Random();
      boolean b = r.nextBoolean();
      System.out.println("# b is ... " + b + " #");

      System.out.println("Result = " + 
         (b ? "It's true." : "It's false."));
      
      String s = b ? "TRUE_CASE" : "FALSE_CASE";
      System.out.println("s = " + s);
   }
}
