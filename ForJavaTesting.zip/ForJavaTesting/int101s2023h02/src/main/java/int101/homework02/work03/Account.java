package int101.homework02.work03;

import int101.homework02.work02.Person;

public class Account {
    private static long nextNo = 100_000_000;
    private final long no;
    private Person owner;
    private double balance;

    public Account(Person owner) {
        if (owner == null) throw new NullPointerException("owner can't be null");
        this.owner = owner;
        this.balance = 0.0;

    }
}
