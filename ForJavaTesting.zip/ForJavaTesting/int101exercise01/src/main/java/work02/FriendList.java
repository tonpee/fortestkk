package work02;

public class FriendList {
    private final String friend;

    private FriendList next;

    private FriendList(String friend) {
        this.friend = friend;
    }

    public static FriendList newList() {
        return new FriendList("");
    }

    public boolean addFriend(String friend) {
        if (friend == null || friend.isBlank()) {

        }
    }
}
