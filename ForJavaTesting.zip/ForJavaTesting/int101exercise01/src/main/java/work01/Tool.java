package work01;

public final class Tool {

    public static void main(String[] args) {
//        System.out.println(compute(1, 2, "add"));
        System.out.println(digitProduct(2090075));
    }
    private Tool() {
    }

    public static double median(double d0, double d1, double d2) {
        if ((d0 <= d1 && d0 >= d2) || (d0 >= d1 && d0 <= d2)) {
            return d0;
        } else if ((d1 <= d2 && d1 >= d0) || (d1 >= d2 && d1 <= d0)) {
            return d1;
        } else {
            return d2;
        }
    }

    public static double compute(double d0, double d1, String operation) {
        double computed = switch (operation) {
            case "sum", "add", "plus" -> d0 + d1;
            case "differnce", "substract", "minus" -> d0 - d1;
            case "product", "multiply", "times" -> d0 * d1;
            case "division" -> d0 / d1;
            default -> throw new RuntimeException("Invalid Operation");
        };
        return computed;
    }

    public static int digitProduct(int number) {
        if (number < 0) {
            return -1;
        } else if (number == 0) {
            return 1;
        }
        String sNum = String.valueOf(number);
        int sNumLength = sNum.length();
        int product = 1;
        for (int i = 0; i < sNumLength; i++) {

            number /= 10;
            product *= number % 10;
            System.out.println(product);
        }
        return product;
    }
}
